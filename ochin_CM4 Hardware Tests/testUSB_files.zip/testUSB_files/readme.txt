USB test procedure

The Raspberry Pi CM4 module provides only one USB port, which is used both to flash the eMMC of the cm4 and for the normal use of the board to connect devices. 
The ochin board has a 4ports USB-HUB, connected to the CM4 module, in order to increase to 4 the number of the USB ports. 
The purpose of this procedure is to test the functionality of the 4 USB ports made available by the ochin board, and therefore the correct design of the pcb.

**************************************************************************************************************
What you need to test:
1x ochin card + cm4 module
1x raspberry pi 4 + microsd card
1x usb type-c cable
1x GHS 4pin to usb Type A cable

**************************************************************************************************************
The test is based on a software (testusb.c) present in the linux kernel, written to verify the functionality of the device drivers.
Informations about this software can be found at this link: http://www.linux-usb.org/usbtest/

In order to carry out the test, another hardware device must be connected to the affected USB port. This device must contain software capable of answering calls 
on the USB port for the test to be successful. In our case we use a Raspberry Pi 4 in a mode called "Gadget Device Zero". 
It is important to use an rpi4 (or an rpi zero) because the USB type-c used for the power supply must also work in device mode (it is not the same for the other Raspberry models).

**************************************************************************************************************
Prepare the Raspberry Compute Module 4 + ochin board:
1: flash the Raspberry Pi OS Lite Debian version 10(buster) to the sd (link: https://downloads.raspberrypi.org/raspios_oldstable_lite_armhf/images/raspios_oldstable_lite_armhf-2022-04-07/2022-04-04-raspios-buster-armhf-lite.img.xz )
	I suggest to use the Raspberry Pi imager software, in order to also configure the WiFi network and enable the ssh.
2: enable the USB interface (disabled by default on CM4). Edit the file “/boot/config.txt” and add
	dtoverlay=dwc2,dr_mode=host
	at the end of the file
3: copy the content of the testusb.zip file in the home folder
4: install "screen" with "sudo apt-get install screen" , this is needed to keep the test running even if you disconnect from terminal

**************************************************************************************************************
Prepare the Raspberry Pi 4 to function as a device:
1: flash the Raspberry Pi OS Lite Debian version 10(buster) to the sd (link: https://downloads.raspberrypi.org/raspios_oldstable_lite_armhf/images/raspios_oldstable_lite_armhf-2022-04-07/2022-04-04-raspios-buster-armhf-lite.img.xz )
	I suggest to use the Raspberry Pi imager software, in order to also configure the WiFi network and enable the ssh.
2: edit the file “/boot/cmdline.txt” and add
	modules-load=dwc2,g_zero
	at the end of the first line
3: edit the file “/boot/config.txt” and add
	dtoverlay=dwc2
	at the end of the file
**************************************************************************************************************

At this point the Raspberry Pi 4 is ready to work as a device. For this to happen it is necessary to connect the USB Type-C connector of the RPi4 to one of the 4 USB ports of the ochin board. 
At boot the Raspberry Pi 4 will realize that it is connected to a USB port (and not to a power supply as usual) and will enter "Gadget Device Zero" mode.
To do so,  you will need a USB Type-C data cable and a GHS 4Pin <-> USB Type-A (female) adapter cable.
To build the GHS USB adapter cable please take a look at the "öchìn CM4 - Wiring and Suggestions.pdf" doc, page 3/5, at this link https://github.com/ochin-space/ochin-CM4/blob/master/%C3%B6ch%C3%ACn%20CM4%20-%20Wiring%20and%20Suggestions.pdf

NOW YOU'RE READY TO START THE TEST
1: connect the RPi4 to the first USB port of the ochin board (using the adapter cables)
2: power on the ochin board
3: connect to the CM4 via ssh
4: sending the "lsusb" command you should see the list of the usb interfaces and the "Gadget Device Zero" connected
5: use screen and the test2file.sh script to start the test logging the result to a file and keep it running after the terminal disconnects (this is for long runs)
	screen sudo ./test2file.sh USB3_test1_ochin_CM4.txt 
	not the test is running in the background...

to see the active screen process:
	screen -list
	
	There is a screen on:
			2410.pts-3.pi        (19/02/22 16:10:26)     (Attached)
	1 Socket in /run/screen/S-pi.
	
to stop the screen process
	screen -X -S "2410.pts-3.pi" quit

**************************************************************************************************************
Inside of the .zip file there are the test result on one of the ochin board from the first 150pcs batch.
I've run the test for at least 4 hours, in case you want to do the same i suggest to put a fan in front of the boards to cool them down.