sudo ./test.sh >> $1
